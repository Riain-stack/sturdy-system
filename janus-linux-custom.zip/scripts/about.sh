#!/bin/bash
echo "🧠 Janus - Arch + Hyprland"
echo "Powered by ChatGPT - Terminal ready."
